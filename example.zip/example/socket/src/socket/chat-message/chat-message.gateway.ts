import { HttpService } from '@nestjs/axios';
import {
  ConnectedSocket,
  MessageBody,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import { Socket, Server } from 'socket.io';
import { Api } from 'src/api/api';
import { getSocketByUserId } from 'src/utils/getSocketByUserId';
import { Store } from 'src/utils/store';

@WebSocketGateway()
export class ChatMessageGateway {
  constructor(private readonly httpService: HttpService) {}

  @WebSocketServer()
  server: Server;
  @SubscribeMessage('chat message')
  handleTip(@MessageBody() values, @ConnectedSocket() client: Socket): void {
    const { body, room, recipientId } = values;
    const { token, username } = Store.getSocketState(client.id);
    if (body && (room || recipientId) && username && token) {
      const path =
        'api/chat/' +
        (room ? room + '/message' : recipientId + '/init-private-message');
      const axios: Api = new Api(this.httpService, client.id, token);
      axios.sendMessageInChat(path, body).then((response) => {
        if (response.status === 201) {
          if (room) {
            if (recipientId) {
              client.join(room);
              client.emit('room create', room);
            }
          }
        }
      });
    }
  }
}
