import {
  ConnectedSocket,
  MessageBody,
  SubscribeMessage,
  WebSocketGateway,
  OnGatewayDisconnect,
  OnGatewayConnection,
} from '@nestjs/websockets';
import { Socket } from 'socket.io';
import { HttpService } from '@nestjs/axios';
import { Api } from 'src/api/api';
import { Store } from 'src/utils/store';

@WebSocketGateway({ cors: true })
export class AuthorizationGateway
  implements OnGatewayDisconnect, OnGatewayConnection
{
  constructor(private readonly httpService: HttpService) {}
  @SubscribeMessage('authorization')
  handleAuthorization(
    @MessageBody() token: string,
    @ConnectedSocket() client: Socket,
  ): void {
    const axios: Api = new Api(this.httpService, client.id, token);
    axios.authByToken('api/user').then((resp) => {
      client.emit('authorization', resp);
    });
  }
  handleConnection(client: Socket) {
    client.emit('connection', {
      information: { state: 'Connect', id: client.id },
    });
    Store.addSocketState(client.id);
  }
  handleDisconnect(client: Socket) {
    Store.deleteSocketState(client.id);
    client.emit('disconnection', { information: 'Disconnect' });
    client.disconnect();
  }
}
