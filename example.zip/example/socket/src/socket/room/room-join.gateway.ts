import {
  ConnectedSocket,
  MessageBody,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { getUserListByRoom } from 'src/utils/getUserListByRoom';

@WebSocketGateway()
export class RoomJoinGateway {
  @WebSocketServer()
  server: Server;
  @SubscribeMessage('room join')
  handleMessage(
    @ConnectedSocket() client: Socket,
    @MessageBody() body: any,
  ): void {
    client.join(body.room);
    getUserListByRoom(body.room, this.server);
  }
}
