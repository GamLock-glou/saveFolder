import {
  ConnectedSocket,
  MessageBody,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import { Socket, Server } from 'socket.io';
import { getUserListByRoom } from 'src/utils/getUserListByRoom';

@WebSocketGateway()
export class RoomLeaveGateway {
  @WebSocketServer()
  server: Server;
  @SubscribeMessage('room leave')
  handleMessage(
    @ConnectedSocket() client: Socket,
    @MessageBody() body: any,
  ): void {
    client.leave(body.room);
    getUserListByRoom(body.room, this.server);
  }
}
