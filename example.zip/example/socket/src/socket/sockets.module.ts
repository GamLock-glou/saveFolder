import { Module } from '@nestjs/common';
import { AuthorizationGateway } from './authorization/authorization.gateway';
import { HttpModule } from '@nestjs/axios';
import { TipGateway } from './tip/tip.gateway';
import { ChatMessageGateway } from './chat-message/chat-message.gateway';
import { RoomJoinGateway } from './room/room-join.gateway';
import { RoomLeaveGateway } from './room/room-leave.gateway';

@Module({
  imports: [HttpModule],
  providers: [
    AuthorizationGateway,
    TipGateway,
    ChatMessageGateway,
    RoomJoinGateway,
    RoomLeaveGateway,
  ],
})
export class SocketsModule {}
