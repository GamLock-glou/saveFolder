import { HttpService } from '@nestjs/axios';
import {
  ConnectedSocket,
  MessageBody,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { Api } from 'src/api/api';
import { Store } from 'src/utils/store';
import { messageBodyTipType } from 'src/utils/type';

@WebSocketGateway()
export class TipGateway {
  constructor(private readonly httpService: HttpService) {}
  @WebSocketServer()
  server: Server;
  @SubscribeMessage('tip')
  handleTip(
    @MessageBody() body: messageBodyTipType,
    @ConnectedSocket() client: Socket,
  ): void {
    const { room } = body;
    const { username, token } = Store.getSocketState(client.id);
    if (room && username && token) {
      const axios: Api = new Api(this.httpService, client.id, token);
      axios.donationsTip(`api/chat/${room}/tip`, body).then((response) => {
        if (response.status && response.data.transaction_id) {
          this.server.in(room).emit('tip', response.data);
        }
      });
    }
  }
}
