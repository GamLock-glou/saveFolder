import { HttpService } from '@nestjs/axios';
import { AxiosError, AxiosResponse } from 'axios';
import { Store } from 'src/utils/store';
import { messageBodyTipType } from 'src/utils/type';

export class Api {
  private instance;
  constructor(
    private readonly httpService: HttpService,
    private readonly idSocket: string,
    private readonly token: string,
  ) {
    this.instance = {
      baseURL: 'https://camsandfans.com/',
      headers: {
        Accept: 'application/json',
        Authorization: 'Bearer ' + token,
      },
    };
  }

  public async authByToken(path): Promise<Record<any, any>> {
    return await this.httpService.axiosRef
      .get<AxiosResponse>(`${this.instance.baseURL}${path}`, {
        headers: this.instance.headers,
      })
      .then((response: any) => {
        const data = {
          statusCode: response.status,
          username: response.data.username,
          name: response.data.name,
        };
        Store.addSocketState(
          this.idSocket,
          response.data.id,
          response.data.username,
          this.token,
          response.data.name,
        );
        return data;
      })
      .catch((error: AxiosError) => {
        return {
          statusCode: error.response.status,
          message: 'Invalid token.',
        };
      });
  }

  public async donationsTip(
    path: string,
    body: messageBodyTipType,
  ): Promise<Record<any, any>> {
    const { amount, activity } = body;
    return await this.httpService.axiosRef
      .post<AxiosResponse>(
        `${this.instance.baseURL}${path}`,
        {
          type: 'tip',
          amount: amount,
          activity: activity,
        },
        {
          headers: this.instance.headers,
        },
      )
      .then((response: any) => {
        return {
          status: response.status,
          data: response.data,
        };
      })
      .catch((error: AxiosError) => {
        return {
          status: error.response.status,
          data: error.response.data,
        };
      });
  }

  public async sendMessageInChat(
    path: string,
    body,
  ): Promise<Record<any, any>> {
    return await this.httpService.axiosRef
      .post<AxiosResponse>(
        `${this.instance.baseURL}${path}`,
        {
          type: 'text',
          body: body,
        },
        {
          headers: this.instance.headers,
        },
      )
      .then((response: any) => {
        return {
          status: response.status,
          data: response.data,
        };
      })
      .catch((error: AxiosError) => {
        return {
          status: error.response.status,
          data: error.response.data,
        };
      });
  }
}
