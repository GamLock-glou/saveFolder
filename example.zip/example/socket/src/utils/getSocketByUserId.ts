import { Store } from './store';

export async function getSocketByUserId(userId) {
  const sockets = Store.getAllSocketState();
  let result = null;
  Object.keys(sockets).forEach((key) => {
    if (sockets[key] === userId) {
      result = sockets;
    }
  });
  return result;
}
