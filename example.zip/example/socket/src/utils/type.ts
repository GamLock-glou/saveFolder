export interface SocketState {
  userId: number;
  username: string;
  name: string;
  token: any;
}

export interface messageBodyTipType {
  amount: number;
  activity: string | null;
  room: string;
}
