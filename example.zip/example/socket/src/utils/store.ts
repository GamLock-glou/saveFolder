import { SocketState } from './type';

export class Store {
  private static socketState: Record<string, SocketState> = {};

  public static addSocketState(
    idSocket,
    id = null,
    username = null,
    token = null,
    name = null,
  ): void {
    this.socketState[idSocket] = {
      userId: id,
      username: username,
      token: token,
      name: name,
    };
  }
  public static deleteSocketState(id): void {
    delete this.socketState[id];
  }
  public static getToken(id): string {
    return this.socketState[id].token;
  }
  public static getSocketState(id): SocketState {
    return this.socketState[id];
  }
  public static getAllSocketState(): Record<string, SocketState> {
    return this.socketState;
  }
}
