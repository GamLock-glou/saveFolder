import { Server } from 'socket.io';
import { Store } from './store';

export async function getUserListByRoom(room: string, server: Server) {
  //TODO: extend user info
  let users = [];
  const anonymousUsers = 0;
  const allSocketState = Store.getAllSocketState();
  Object.keys(allSocketState).forEach((socketState: string) => {
    if (allSocketState[socketState].username) {
      users.push(allSocketState[socketState]);
    }
  });

  // remove duplicates
  users = users.filter(
    (v, i, a) => a.findIndex((v2) => v2.username === v.username) === i,
  );

  server.in(room).emit('room users', {
    room: room,
    users: users,
    anonymousUsers: anonymousUsers,
  });
}
