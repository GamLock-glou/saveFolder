import './App.css';
import { io } from "socket.io-client";
import { useEffect } from 'react';
import { useState } from 'react';

function App() {
  const socket = io.connect("http://localhost:4000");
  useEffect(()=>{
    socket.on('authorization', (data) => {
      console.log(data)
    })
    socket.on('tip', (data) => {
      console.log(data)
    })
    socket.on('room users', (data) => {
      console.log(data)
    })
    socket.on('room create', (data) => {
      console.log(data)
    })
  },[])
  const onClick = () => {
    socket.emit('authorization', "524|h450EMIrNEDDRYn1d9Dle3rXF5CCmvCUXQuAruLw")
  }
  const onClickTip = () => {
    socket.emit('tip', {amount: 20, room: "T1iYWrxdegTbOy2j"})
  }

  const onClickChat = () => {
    socket.emit('chat message', {body: 'Жопа', room: 'UAedZkqQuloU8x8x'})
  }
  const onClickRoomJoin = () => {
    socket.emit('room join', {room: "T1iYWrxdegTbOy2j"})
  }
  const onClickRoomLeave = () => {
    socket.emit('room leave', {room: "T1iYWrxdegTbOy2j"})
  }
  return (
    <div className="App">
      <button onClick={onClick}>click</button>
      <button onClick={onClickTip}>click tip</button>
      <button onClick={onClickRoomJoin}>join to the room</button>
      <button onClick={onClickRoomLeave}>leave in the room</button>
      <button onClick={onClickChat}>click chat message</button>

    </div>
  );
}

export default App;
