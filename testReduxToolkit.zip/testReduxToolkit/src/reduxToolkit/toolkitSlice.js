import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

export const testThunk = createAsyncThunk(
  'testThunk',
  async (_, thunkAPI) => {
    console.log(thunkAPI)
    const obj = {
      data: {
        name: 'Eugenu',
        age: 21
      }
    };
    return obj.data
  }
)

const toolkitSlice = createSlice({
  name: 'toolkit',
  initialState: {
    count: 0,
    todo: ['hi', 'hello', 'what up']
  },
  reducers: {
    increment(state) {
      state.count = state.count + 1;
    },
    decrement(state) {
      state.count = state.count - 1;
    },
    addTodo(state, action) {
      state.todo.push(action.payload)
    },
    removeLastTodo(state) {
      state.todo.pop()
    }
  },
  extraReducers: (builder) => {
    builder.addCase(testThunk.fulfilled.type, (state, action) => {
      state.values = action.payload
    })
  },

})

export default toolkitSlice.reducer;
export const {increment, decrement, addTodo, removeLastTodo} = toolkitSlice.actions