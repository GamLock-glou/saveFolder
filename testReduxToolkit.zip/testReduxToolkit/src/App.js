import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import './App.css';
import { decrement, increment, addTodo, removeLastTodo, testThunk} from './reduxToolkit/toolkitSlice';

function App() {
  const counter = useSelector(state => state.testReducer.count)
  const todos = useSelector(state => state.testReducer.todo)
  const values = useSelector(state => state.testReducer?.values)
  console.log(values)
  useEffect(()=> {
    dispatch(testThunk());
  }, [])
  const dispatch = useDispatch();
  return (
    <div className="App">
      <div onClick={()=>dispatch(increment())}>increment</div>
      <div>{counter}</div>
      <div onClick={()=>dispatch(decrement())}>decrement</div>
      <div className='buttons'>
        <div className='button' onClick={() => dispatch(addTodo(prompt()))}>add todo</div>
        <div className='button' onClick={() => dispatch(removeLastTodo())}>delete last todo</div>
      </div>
      <div className='todos'>
        {todos.map((todo) => {
          return <div>
            {todo}
          </div>
        })}
      </div>
      <div>{values.name} {values.age}</div>
    </div>
  );
}

export default App;
