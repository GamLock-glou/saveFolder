export enum Colors {
  WHITE = 'white',
  BLACK = 'black',
}