import React, { FunctionComponent } from 'react';
import { Cell } from '../utils/Cell';

interface CellProps {
  cell: Cell;
  selected: boolean;
  onClick: (cell: Cell) => void
}

export const CellComponent:FunctionComponent<CellProps> = ({cell, selected, onClick}) => {
  return (
    <div
      className={
        ['cell',
          cell.color,
          selected && 'selected',
          (cell.available && cell.figure) && 'mayBeKillFigure'
        ].join(' ')
      }
      onClick={()=>onClick(cell)}
    >
      {cell.available && !cell.figure && <div className='available'/>}
      {cell.figure?.logo && <img src={cell.figure.logo} alt={`${cell.figure.name} ${cell.figure.color}`}/>}
    </div>
  );
};