import { HandFiveCardDraw } from "./Hand/HandFiveCardDraw";
import { HandOmahaHoldem } from "./Hand/HandOmahaHoldem";
import { HandTexasHoldem } from "./Hand/HandTexasHoldem";
import { Combination, GameName } from "./utils/enums";
import { getCardWithCardPowerAndSuit } from "./utils/functions/utlis";
import { ArrayPowerHandsByRank, CardType, PowerHands, PowerHandsWithCardsOutOfCombination } from "./utils/type";

export class Solver {

    process(line: string): string {
        const [gameName, board, ...hands]: string[] = line.split(' ');
        return this.startingGame(gameName, board, hands);
    }

    startingGame(gameName, board, hands): string {
        switch (gameName) {
            case GameName.FiveCardDraw: {
                hands.unshift(board)
                return this.fiveCardDraw(hands);
            };
            case GameName.OmahaHoldem: {
                return this.omahaHoldem(board, hands);
            };
            case GameName.TexasHoldem: {
                return this.texasHoldem(board, hands);
            };
            default: return '';
        }
    }

    fiveCardDraw(hands): string {
        const powerHands: PowerHands[] = hands.map(hand => {
            const powerHand = new HandFiveCardDraw(hand);
            return {powerHand: powerHand.getPowerHand(), hand}
        });
        return this.sortPowerHands(powerHands)
    }

    omahaHoldem(board: string, hands: string[]): string {
        const powerHands: PowerHands[] = hands.map(hand => {
            const powerHand = new HandOmahaHoldem(board, hand);
            return {powerHand: powerHand.getPowerHand(), hand}
        });
        return this.sortPowerHands(powerHands)
    }

    texasHoldem(board, hands): string {
        const powerHands: PowerHands[] = hands.map(hand => {
            const powerHand = new HandTexasHoldem(board, hand);
            return {powerHand: powerHand.getPowerHand(), hand}
        });
        return this.sortPowerHands(powerHands)
    }

    sortPowerHands(powerHands: PowerHands[]):string {
        this.sortRankPowerHands(powerHands);
        const arrayOfPowerHandsByRank: ArrayPowerHandsByRank[] = []
        powerHands.forEach(powerHand => {
            const filterPowerHandsByRank: PowerHands[] = powerHands.filter(ph => ph.powerHand.rank === powerHand.powerHand.rank)
            if(filterPowerHandsByRank.length) {
                arrayOfPowerHandsByRank.push({filterPowerHandsByRank, rank: powerHand.powerHand.rank});
            }
            powerHands = powerHands.filter(ph => ph.powerHand.rank !== powerHand.powerHand.rank)
        })
        const sortCards: string[] = []
        arrayOfPowerHandsByRank.forEach((powerHandsByRank: ArrayPowerHandsByRank) => {
            switch (powerHandsByRank.rank) {
              case Combination.HighCard: {
                sortCards.push(this.sortHandsHighCard(powerHandsByRank.filterPowerHandsByRank));
                break;
              }
              case Combination.Pair: {
                sortCards.push(this.sortHandsPairs(powerHandsByRank.filterPowerHandsByRank));
                break;
              }
              case Combination.TwoPair: {
                sortCards.push(this.sortHandsPairs(powerHandsByRank.filterPowerHandsByRank));
                break;
              }
              case Combination.ThreeOfAKind: {
                sortCards.push(this.sortHandsPairs(powerHandsByRank.filterPowerHandsByRank));
                break;
              }
              case Combination.Straight: {
                sortCards.push(this.sortHandsStraight(powerHandsByRank.filterPowerHandsByRank))
                break;
              }
              case Combination.Flush: {
                sortCards.push(this.sortHandsFlush(powerHandsByRank.filterPowerHandsByRank))
                break;
              }
              case Combination.FullHouse: {
                sortCards.push(this.sortHandsPairs(powerHandsByRank.filterPowerHandsByRank));
                break;
              }
              case Combination.FourOfAKind: {
                sortCards.push(this.sortHandsPairs(powerHandsByRank.filterPowerHandsByRank));
                break;
              }
              case Combination.StraightFlush: {
                sortCards.push(this.sortHandsStraight(powerHandsByRank.filterPowerHandsByRank));
                break;
              }
            }
          })
          return sortCards.join(' ')
    }

    private sortRankPowerHands(powerHands: PowerHands[]) {
        powerHands.sort((a, b) => {
            return a.powerHand.rank - b.powerHand.rank
        })
    }

    private sortHandsHighCard(powerHands: PowerHands[]): string {
        const newSortElement = powerHands.map((powerHand) => {
            const cards = getCardWithCardPowerAndSuit(powerHand.hand).sort((a, b) => b.cardPower - a.cardPower);
            return {cards, powerHand}
        })
        newSortElement.sort((a,b) => {
            for (let i = 0; i < a.cards.length; i++) {
                const a1 = a.cards[i].cardPower;
                const b1 = b.cards[i].cardPower;
                if(a1 > b1) {
                    return 1
                } else if (a1 === b1) {
                    continue;
                }
                return -1
            }
            return -1
        })
        const hands: string[] = newSortElement.map(el => el.powerHand.hand);
        return this.checkingCardsForEquality(hands).join(' ')
    }

    private sortHandsPairs(powerHands: PowerHands[]): string {
        const powerHandsWithCardsOutOfCombination: PowerHandsWithCardsOutOfCombination[] = powerHands.map(powerHand => {
            const cards: CardType[] = getCardWithCardPowerAndSuit(powerHand.hand).sort((a, b) => b.cardPower - a.cardPower);
            const cardsOutOfCombination: CardType[] = cards.filter(card =>
                !powerHand.powerHand.combination.some((c) => (c.cardPower === card.cardPower && card.suit === c.suit)));
            cardsOutOfCombination.sort((a, b) => a.cardPower - b.cardPower)
            return {cardsOutOfCombination, powerHand}
        })
        this.sortHandsWithCardsOutOfCombination(powerHandsWithCardsOutOfCombination)
        const newPowerHands = powerHandsWithCardsOutOfCombination.map(ph => ph.powerHand);
        newPowerHands.sort((a, b) => a.powerHand.combination[1]?.cardPower - b.powerHand.combination[1]?.cardPower);
        newPowerHands.sort((a, b) => a.powerHand.combination[0]?.cardPower - b.powerHand.combination[0]?.cardPower);
        const hands: string[] = newPowerHands.map((ph => ph.hand));
        return this.checkingCardsForEquality(hands).join(' ');
    }

    private sortHandsStraight(powerHands: PowerHands[]): string {
        powerHands.sort((a, b) => a.powerHand.combination[0]?.cardPower - b.powerHand.combination[0]?.cardPower);
        const hands: string[] = [powerHands[0]?.hand]
        for (let i = 0; i < powerHands.length; i++) {
            if(powerHands[i+1]) {
                const a = powerHands[i].powerHand.combination[0]?.cardPower;
                const b = powerHands[i+1]?.powerHand.combination[0]?.cardPower;
                if(a === b) {
                    hands[i] += '='+powerHands[i+1].hand;
                    continue;
                }
                hands.push(powerHands[i+1]?.hand)
            }
        }
        return hands.join(' ')
    }

    private sortHandsFlush(powerHands: PowerHands[]): string {
        powerHands.sort((a,b) => {
            for (let i = 0; i < a.powerHand.combination.length; i++) {
                const a1 = a.powerHand.combination[i].cardPower;
                const b1 = b.powerHand.combination[i].cardPower;
                if(a1 > b1) {
                    return 1
                } else if (a1 === b1) {
                    continue;
                }
                return -1
            }
            return -1
        })
        return powerHands.map(pw => pw.hand).join(' ');
    }

    private sortHandsWithCardsOutOfCombination(hands: PowerHandsWithCardsOutOfCombination[]) {
        hands.sort((a, b) => {
            for (let i = a.cardsOutOfCombination.length-1; i >= 0; i--) {
                if (a.cardsOutOfCombination[i]?.cardPower > b.cardsOutOfCombination[i]?.cardPower) {
                    return 1
                } else if(a.cardsOutOfCombination[i]?.cardPower === b.cardsOutOfCombination[i]?.cardPower) {
                    continue
                }
                return -1
            }
            return -1
        });
      }

    private checkingCardsForEquality(hands: string[]): string[] {
        const newCards: string[] = [hands[0]];
        for(let i = 0; i < hands.length - 1; i++) {
            const a = getCardWithCardPowerAndSuit(hands[i]).sort((a, b) => b.cardPower - a.cardPower);
            const b = getCardWithCardPowerAndSuit(hands[i + 1]).sort((a, b) => b.cardPower - a.cardPower);
            let counter = 0;
            for(let indexCardPower = 0; indexCardPower < a.length; indexCardPower++) {
                if (a[indexCardPower].cardPower === b[indexCardPower].cardPower) {
                    counter++
                }
            }

          if(counter === a.length) {
            newCards[i] += '='+hands[i+1];
            continue;
          }
          newCards.push(hands[i+1])
        }
        return newCards
      }
}