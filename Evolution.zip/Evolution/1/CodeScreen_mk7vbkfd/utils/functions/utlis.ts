import { CharCardPower } from "../enums";
import { CardType } from "../type";

export function translateCard(value: string): number {
  return !isNaN(+value)
  ? +value
  : CharCardPower[value]
}

export function getCardWithCardPowerAndSuit(cards): CardType[] {
  const newCardArray: string[] = cards.split('');
  const newCards: any[] = [];
  for(let i: number = 0; i < newCardArray.length; i += 2) {
    const cardPower: number = translateCard(newCardArray[i]);

    newCards.push({cardPower: cardPower, suit: newCardArray[i+1]});
  }
  return newCards
}

export function flatten(array)
{
    if(array.length == 0)
        return array;
    else if(Array.isArray(array[0]))
        return flatten(array[0]).concat(flatten(array.slice(1)));
    else
        return [array[0]].concat(flatten(array.slice(1)));
}