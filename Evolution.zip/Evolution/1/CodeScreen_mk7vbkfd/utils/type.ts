export interface CardType {
  cardPower: number;
  suit: string;
}

export interface CardPairWithCountType {
  cardInCombination: CardType[];
  count: number;
}

export interface PowerHands {
  powerHand: PowerHand;
  hand: string;
}

export interface PowerHand {
  combination: CardType[];
  rank: number;
}

export interface ArrayPowerHandsByRank {
  filterPowerHandsByRank: PowerHands[];
  rank: number;
}

export interface PowerHandsWithCardsOutOfCombination {
  cardsOutOfCombination: CardType[];
  powerHand: PowerHands;
}