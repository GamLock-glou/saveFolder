export enum GameName {
  FiveCardDraw = 'five-card-draw',
  OmahaHoldem = 'omaha-holdem',
  TexasHoldem = 'texas-holdem'
}

export enum CharCardPower {
  T = 10,
  J = 11,
  Q = 12,
  K = 13,
  A = 14,
}

export enum Combination {
  HighCard,
  Pair,
  TwoPair,
  ThreeOfAKind,
  Straight,
  Flush,
  FullHouse,
  FourOfAKind,
  StraightFlush,
}