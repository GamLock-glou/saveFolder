import { Combination } from "../utils/enums";
import { flatten, getCardWithCardPowerAndSuit } from "../utils/functions/utlis";
import { CardPairWithCountType, CardType } from "../utils/type";
import { HandTexasHoldem } from "./HandTexasHoldem";

export class HandFiveCardDraw extends HandTexasHoldem {
  protected rank: number;
  protected combination: any;
  protected hand: string;
  constructor(hand: string) {
    super(hand, '')
    this.rank = 0;
    this.combination = [];
    this.hand = hand;
    this.getHighCard(hand);
    const cards = this.sortCards(hand);
    this.combination = this.checkStraightFlush(cards);
  }
}