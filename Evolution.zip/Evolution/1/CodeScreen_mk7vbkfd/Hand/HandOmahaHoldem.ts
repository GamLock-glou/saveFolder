import { Combination } from "../utils/enums";
import { flatten } from "../utils/functions/utlis";
import { CardPairWithCountType, CardType } from "../utils/type";
import { HandTexasHoldem } from "./HandTexasHoldem";

export class HandOmahaHoldem extends HandTexasHoldem {

  protected checkFullHouse(cards): CardType[] {
    const pairs: CardType[][] = this.getPair([...cards]);
    if(pairs.length) {
      const allCombination: CardPairWithCountType[] = pairs.map((pair) => {
        return this.getCardHandCombination(pair);
      });
      allCombination.sort((a, b) => b.count - a.count)
      if (allCombination[0].count === 3 && allCombination[1]?.count === 2 &&
        ((allCombination[0].cardInCombination.length > 1 || allCombination[1].cardInCombination.length > 1) ||
        (allCombination[0].cardInCombination.length > 0 && allCombination[1].cardInCombination.length > 0))) {
        const newCombination = flatten(allCombination.map(combination => combination.cardInCombination));
        this.rank = Combination.FullHouse;
        return newCombination.splice(0, 2)
      }
    }
    return this.checkFlush(cards)
  }

  protected checkFlush(cards: CardType[]): CardType[] {
    const flush: CardType[] = this.getFlush([...cards].reverse());
    if(flush.length) {
      const countHandSuitFlush = this.getCardHandCombination(flush).cardInCombination.length;
      if(countHandSuitFlush > 1) {
        // console.log('flush')
        this.rank = Combination.Flush;
        return flush;
      }
    }
    return this.checkStraight(cards)
  }
  protected checkStraight(cards: CardType[]): CardType[] {
    const straight: CardType[] = this.getStraight([...cards])
    if(straight.length) {
      const handStraight = this.getCardHandCombination(straight).cardInCombination;
      if(handStraight.length > 1) {
        const indexPowerCard = straight.reverse().findIndex(hand => JSON.stringify(hand) === JSON.stringify(handStraight[1]))
        this.rank = Combination.Straight;
        return [straight.splice(indexPowerCard, indexPowerCard+5)[0]]
      }
    }
    return this.checkTreeOfAKind(cards)
  }
}