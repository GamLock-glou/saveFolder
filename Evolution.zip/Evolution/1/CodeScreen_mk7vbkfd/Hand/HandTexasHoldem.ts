import { Combination } from "../utils/enums";
import { flatten, translateCard } from "../utils/functions/utlis";
import { getCardWithCardPowerAndSuit } from '../utils/functions/utlis'
import { CardPairWithCountType, CardType } from "../utils/type";

export class HandTexasHoldem {
  protected rank: number;
  protected combination: any;
  protected hand: string;
  constructor(board: string, hand: string) {
    this.rank = 0;
    this.combination = [];
    this.hand = hand;
    this.getHighCard(hand);
    const cards = this.sortCards(board+hand);
    this.combination = this.checkStraightFlush(cards);
  }

  public getPowerHand() {
    const {rank, combination} = this;
    return {combination, rank}
  }
  protected sortCards(cards) {
    const newCards = getCardWithCardPowerAndSuit(cards);
    newCards.sort(function(a,b) {
        return a.cardPower - b.cardPower;
    });
    return newCards;
  }

  protected checkStraightFlush(cards: CardType[]): CardType[] {
    const straight: CardType[] = this.getStraight([...cards]);
    if(straight.length) {
      const straightFlush: CardType[] = this.getFlush([...straight]);
      if(straightFlush.length) {
      this.rank = Combination.StraightFlush;
      return [straightFlush[0]];
      }
    }
    return this.checkFourOfAKind(cards)
  }
  protected checkFourOfAKind(cards: CardType[]): CardType[] {
    const pairs = this.getPair([...cards]);
    if(pairs.length) {
      const allCombination: CardPairWithCountType[] = pairs.map((pair: CardType[]) => {
        return this.getCardHandCombination(pair);
      });
      allCombination.sort((a: CardPairWithCountType, b: CardPairWithCountType) => b.count - a.count)
      if (allCombination[0].count === 4) {
        const newCombination: CardType[] = flatten(allCombination.map(combination => combination.cardInCombination));
        this.rank = Combination.FourOfAKind;
        return newCombination.splice(0, 1)
      }
    }
    return this.checkFullHouse(cards)
  }
  protected checkFullHouse(cards): CardType[] {
    const pairs: CardType[][] = this.getPair([...cards]);
    if(pairs.length) {
      const allCombination: CardPairWithCountType[] = pairs.map((pair) => {
        return this.getCardHandCombination(pair);
      });
      allCombination.sort((a, b) => b.count - a.count)
      if (allCombination[0].count === 3 && allCombination[1]?.count === 2) {
        const newCombination = flatten(allCombination.map(combination => combination.cardInCombination));
        this.rank = Combination.FullHouse;
        return newCombination.splice(0, 2)
      }
    }
    return this.checkFlush(cards)
  }
  protected checkFlush(cards: CardType[]): CardType[] {
    const flush: CardType[] = this.getFlush([...cards].reverse());
    if(flush.length) {
      this.rank = Combination.Flush;
      return flush;
    }
    return this.checkStraight(cards)
  }
  protected checkStraight(cards: CardType[]): CardType[] {
    const straight: CardType[] = this.getStraight([...cards])
    if(straight.length) {
      this.rank = Combination.Straight;
      return [straight[0]]
    }
    return this.checkTreeOfAKind(cards)
  }
  protected checkTreeOfAKind(cards: CardType[]): CardType[] {
    const pairs: CardType[][] = this.getPair([...cards]);
    if(pairs.length) {
      const allCombination: CardPairWithCountType[] = pairs.map((pair: CardType[]) => {
        return this.getCardHandCombination(pair);
      });
      allCombination.sort((a: CardPairWithCountType, b: CardPairWithCountType) => b.count - a.count)
      if (allCombination[0].count === 3) {
        const newCombination: CardType[] = flatten(allCombination.map(combination => combination.cardInCombination));
        this.rank = Combination.ThreeOfAKind;
        return newCombination.splice(0, 1);
      }
    }
    return this.checkTwoPair(cards)
  }
  protected checkTwoPair(cards: CardType[]): CardType[] {
    const pairs: CardType[][] = this.getPair([...cards]);
    if(pairs.length) {
      const allCombination: CardPairWithCountType[] = pairs.map((pair: CardType[]) => {
        return this.getCardHandCombination(pair);
      });
      allCombination.sort((a: CardPairWithCountType, b: CardPairWithCountType) => b.count - a.count)
      if (allCombination[0].count === 2 && allCombination[1]?.count === 2) {
        const newCombination: CardType[] = flatten(allCombination.map(combination => combination.cardInCombination));
        this.rank = Combination.TwoPair;
        return newCombination.splice(0, 2)
      }
    }
    return this.checkPair(cards)
  }
  protected checkPair(cards: CardType[]): CardType[] {
    const pairs: CardType[][] = this.getPair([...cards]);
    if(pairs.length) {
      const allCombination: CardPairWithCountType[] = pairs.map((pair: CardType[]) => {
        return this.getCardHandCombination(pair);
      });
      allCombination.sort((a: CardPairWithCountType, b: CardPairWithCountType) => b.count - a.count)
      const newCombination: CardType[] = flatten(allCombination.map(combination => combination.cardInCombination))
      this.rank = Combination.Pair;
      return newCombination.splice(0, 1)
    }
    return this.combination
  }
  protected getPair(cards: CardType[]): CardType[][] {
    const combination: CardType[][] = []
    cards.forEach((card: CardType) => {
      const identicalCards = cards.filter((c: CardType) => c.cardPower === card.cardPower);
      if (identicalCards.length > 1) {
        cards = cards.filter(c => c.cardPower !== card.cardPower)
        combination.push(identicalCards);
      }
    })
    return combination.reverse()
  }
  protected getCardHandCombination(pair: CardType[]): CardPairWithCountType {
    const combination: CardPairWithCountType = {
      cardInCombination: [],
      count: pair.length
    }
    const hand = getCardWithCardPowerAndSuit(this.hand)
    const haveA = hand.find((card)=>card.cardPower === 14)
    if(haveA) {
      hand.unshift({cardPower: 1, suit: haveA.suit})
    }
    pair.forEach((card: CardType)=>{
      const isCardInHand = hand.some((c: CardType) => JSON.stringify(card) === JSON.stringify(c));
      if(isCardInHand) {
        combination.cardInCombination.push(card)
      }
    })
    return combination;
  }

  protected getHighCard(hand: string): void {
    const cards = getCardWithCardPowerAndSuit(hand);
    cards.sort((a, b) => b.cardPower - a.cardPower)
    this.combination = [cards[0]];
    this.rank = Combination.HighCard;
  }

  protected getFlush(cards: CardType[]): CardType[] {
    const combination: CardType[][] = []
    cards.forEach((card: CardType) => {
      const filterCard: CardType[] = cards.filter((c: CardType) => card.suit === c.suit);
      cards = cards.filter((c: CardType) => card.suit !== c.suit)
      if (filterCard.length > 4) {
        combination.push(filterCard);
      }
    })
    return flatten(combination);
  }

  protected getStraight(cards: CardType[]): CardType[] {
    const haveA = cards.find((card)=>card.cardPower === 14)
    if(haveA) {
      cards.unshift({cardPower: 1, suit: haveA.suit})
    }
    const combination = cards.reverse().reduce(
      (newCards: CardType[], nextCard: CardType) => {
        if (newCards[newCards.length - 1]?.cardPower === nextCard.cardPower + 1) {
          newCards.push(nextCard);
          return newCards
        }
        if(newCards[newCards.length - 1]?.cardPower === nextCard.cardPower) {
          return newCards
        }
        if(newCards.length > 4) {
          return newCards
        }
        return [nextCard]
      }, []);
    if (combination.length > 4) {
      return combination;
    }
    return []
  }

}