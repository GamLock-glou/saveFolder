import { Cell } from "./cell";

export class Board {
  sizeMatrix;
  cells = [];
  isWin = false;
  step = 0;

  constructor(sizeMatrix = 16) {
    this.sizeMatrix = sizeMatrix;
    this.initBoard()
    this.endGame()
  }

  // создаем доску
  initBoard() {
    const array = [];
    for(let index = 0; index < (this.sizeMatrix); index++) {
      array.push(index);
    }
    this.shuffle(array)
    this.createMatrix(array)
  }
  // меняем местами
  swappingPlaces(emptyCell, currentCell) {
    const emptyValue = emptyCell.value
    if ((emptyCell.x === currentCell.x && (emptyCell.y === currentCell.y+1 || emptyCell.y === currentCell.y-1)) ||
    (emptyCell.y === currentCell.y && (emptyCell.x === currentCell.x+1 || emptyCell.x === currentCell.x-1))) {
      this.cells[emptyCell.y][emptyCell.x].value = currentCell.value;
      this.cells[currentCell.y][currentCell.x].value = emptyValue;
    }
    this.endGame()
    this.step ++;
  }

  // is win?
  endGame() {
    const winArray = [];
    const realyArray = [...this.cells].flat().flatMap(cell => cell.value);
    for(let index = 0; index < this.sizeMatrix; index++) {
      winArray.push(index)
    }
    if(JSON.stringify(realyArray) === JSON.stringify(winArray)) {
      this.isWin = true
    } else {
    this.isWin = false
    }
  }

  // создаем матрицу
  createMatrix(array) {
    const sizeRow = Math.sqrt(this.sizeMatrix);
    const newMatrix = [];
    let index = 0;
    for(let y = 0; y < sizeRow; y++) {
      const row = []
      for(let x = 0; x < sizeRow; x++) {
        const cell = new Cell(x, y, array[index])
        index++
        row.push(cell)
      }
      newMatrix.push(row)
    }
    this.cells = newMatrix
  }


  // рандомный массив
  shuffle(array) {
    array.sort(() => {
      return Math.random() - 0.5
    });
  }
}