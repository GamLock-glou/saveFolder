export class Cell {
  x = null;
  y = null;
  value = null;

  constructor(x, y, value) {
    this.x = x;
    this.y = y;
    this.value = value;
  }
}