import { useEffect, useState } from 'react';
import './App.css';
import { Board } from './utils/board';

function App() {
  const [board, setBoard] = useState(new Board(9));
  const [currentCell, setCurrentCell] = useState(null);
  function sizeMatrix(size) {
    setBoard(new Board(size))
  }

  function dragStartHandler(e, values) {
    setCurrentCell(values)
  }

  function dragLeaveHandler(e) {
  }

  function dragEndHandler(e) {
    setCurrentCell(null)
  }

  function dragOverHandler(e) {
    e.preventDefault();
  }

  function dropHandler(e, values) {
    e.preventDefault();
    if(!values.value) {
      board.swappingPlaces(values, currentCell)
    }
  }

  if(board.isWin) {
    return <div>
      YOU WIN
    </div>
  }

  return (
    <div className="App">
      <div className='boardStyle'>
        <div>
          STEP: {board.step}
        </div>
        {/* <div onClick={() => board.initBoard()}>Refresh matrix</div> */}
        {
          board.cells.map((row, index_row)=>{
            return <div className='rowStyle' key={index_row}>{row.map((cell, index_column) => {
              if(!board.cells[index_row][index_column].value) {
                return <div
                  key={index_column}
                  className='nullSymbol'
                  onDragOver={e => dragOverHandler(e)}
                  onDrop={e => dropHandler(e, board.cells[index_row][index_column])}
                  />
              }
              return <div
                key={index_column}
                className='cellStyle'
                draggable={true}
                onDragStart={e => dragStartHandler(e, board.cells[index_row][index_column])}
                onDragLeave={e => dragLeaveHandler(e)}
                onDragEnd={e => dragEndHandler(e)}
              >
                <img style={{width: '100px', height: '100px'}} src={require(`./img/${board.cells[index_row][index_column].value}.jpg`)} alt='1'/>
                {/* {board.cells[index_row][index_column].value} */}
              </div>
            })}</div>
          })
        }
        <div onClick={()=>{sizeMatrix(4)}}>2X2</div>
        <div onClick={()=>{sizeMatrix(9)}}>3X3</div>
        <div onClick={()=>{sizeMatrix(16)}}>4X4</div>
        <div onClick={()=>{sizeMatrix(25)}}>5X5</div>
        <div onClick={()=>{sizeMatrix(36)}}>6X6</div>
      </div>
    </div>
  );
}

export default App;
